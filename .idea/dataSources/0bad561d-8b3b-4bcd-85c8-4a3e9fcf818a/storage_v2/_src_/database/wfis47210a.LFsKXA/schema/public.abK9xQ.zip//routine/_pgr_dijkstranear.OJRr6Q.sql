create function _pgr_dijkstranear(text, anyarray, bigint, bigint, directed boolean DEFAULT true, OUT seq integer, OUT path_seq integer, OUT start_vid bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    language sql
as
$$
SELECT seq, path_seq, start_vid, node, edge, cost, agg_cost
    FROM _pgr_dijkstra(_pgr_get_statement($1), $2::BIGINT[], ARRAY[$3]::BIGINT[], $5, false, false, $4);
$$;

comment on function _pgr_dijkstranear(text, anyarray, bigint, bigint, boolean, out integer, out integer, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgr_dijkstraNear(Many to One)
- PRE-EXPERIMENTAL
- Parameters:
   - Edges SQL with columns: id, source, target, cost [,reverse_cost]
   - From ARRAY[vertices identifiers]
   - To vertex identifier
   - Stop at nth found
- Optional Parameters
   - directed := true
- Documentation: None
';

alter function _pgr_dijkstranear(text, anyarray, bigint, bigint, boolean, out integer, out integer, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

