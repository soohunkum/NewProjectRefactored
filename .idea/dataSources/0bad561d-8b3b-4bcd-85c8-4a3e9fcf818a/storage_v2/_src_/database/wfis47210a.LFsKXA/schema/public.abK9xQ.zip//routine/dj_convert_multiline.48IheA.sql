create function dj_convert_multiline(multiline_geom geometry, start_point geometry) returns geometry
    language plpgsql
as
$$
DECLARE

	multiline_geom_array geometry[];

	idx integer;

	line_geom geometry;

	temp_line_geom geometry;

BEGIN

	multiline_geom_array = dj_geometry_to_array(multiline_geom);

	RAISE INFO 'multiline_geom_array_length = %', coalesce(array_length(multiline_geom_array, 1), 0);

	idx := dj_get_index_array(multiline_geom_array, start_point);

	

	IF idx = 0 THEN

		RETURN NULL;

	END IF;

	

	IF idx > 0 THEN

		line_geom := multiline_geom_array[idx];

	ELSE

		idx := idx * -1;

		line_geom := ST_Reverse(multiline_geom_array[idx]);

	END IF;

	

	multiline_geom_array := array_remove(multiline_geom_array, multiline_geom_array[idx]);

	

	FOR i IN REVERSE coalesce(array_length(multiline_geom_array, 1), 0) .. 1

	LOOP

		idx := dj_get_index_array(multiline_geom_array, ST_EndPoint(line_geom));

		

		IF idx = 0 THEN

			RAISE INFO '% index idx = 0 CONTINUE', i;

			CONTINUE;

		END IF;

		

		IF idx > 0 THEN

			temp_line_geom := multiline_geom_array[idx];

		ELSE

			idx := idx * -1;

			temp_line_geom := ST_Reverse(multiline_geom_array[idx]);

		END IF;

		

		line_geom := dj_add_point_line(line_geom, temp_line_geom);

		multiline_geom_array := array_remove(multiline_geom_array, multiline_geom_array[idx]);

	END LOOP;

	

	RETURN line_geom;

END

$$;

alter function dj_convert_multiline(geometry, geometry) owner to postgres;

