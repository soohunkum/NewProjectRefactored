create view viw_wtl_userlabel_ps(id, geom, 주기명, 방향각) as
SELECT wtl_userlabel_ps.id,
       wtl_userlabel_ps.geom,
       wtl_userlabel_ps."주기명",
       wtl_userlabel_ps."방향각"
FROM wtl_userlabel_ps;

alter table viw_wtl_userlabel_ps
    owner to postgres;

