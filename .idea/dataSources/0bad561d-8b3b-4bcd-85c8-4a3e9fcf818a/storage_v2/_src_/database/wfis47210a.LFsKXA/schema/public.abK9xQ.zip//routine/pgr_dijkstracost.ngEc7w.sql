create function pgr_dijkstracost(text, text, directed boolean DEFAULT true, OUT start_vid bigint, OUT end_vid bigint, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT start_vid, end_vid, agg_cost
    FROM _pgr_dijkstra(_pgr_get_statement($1), _pgr_get_statement($2), $3, true, true);
$$;

comment on function pgr_dijkstracost(text, text, boolean, out bigint, out bigint, out double precision) is 'pgr_dijkstraCost(Combinations SQL)
- Parameters:
   - Edges SQL with columns: id, source, target, cost [,reverse_cost]
   - Combinations SQL with columns: source, target
- Optional Parameters
   - directed := true
- Documentation:
   - https://docs.pgrouting.org/3.1/en/pgr_dijkstraCost.html
';

alter function pgr_dijkstracost(text, text, boolean, out bigint, out bigint, out double precision) owner to postgres;

