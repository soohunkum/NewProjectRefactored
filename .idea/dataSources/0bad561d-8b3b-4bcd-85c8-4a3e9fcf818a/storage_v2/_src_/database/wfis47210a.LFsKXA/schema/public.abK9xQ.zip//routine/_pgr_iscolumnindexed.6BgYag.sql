create function _pgr_iscolumnindexed(tab text, col text, reporterrs integer DEFAULT 1, fnname text DEFAULT '_pgr_isColumnIndexed'::text) returns boolean
    strict
    language plpgsql
as
$$
DECLARE
    naming record;
    rec record;
    sname text;
    tname text;
    cname text;
    pkey text;
    value boolean;
BEGIN
    SELECT * into naming FROM _pgr_getTableName(tab, 0, fnName);
    sname=naming.sname;
    tname=naming.tname;
    IF sname IS NULL OR tname IS NULL THEN
        RETURN FALSE;
    END IF;
    SELECT * into cname from _pgr_getColumnName(sname, tname, col, 0, fnName) ;
    IF cname IS NULL THEN
        RETURN FALSE;
    END IF;
    select * into value  from _pgr_isColumnIndexed(sname, tname, cname, reportErrs, fnName);
    return value;
END
$$;

comment on function _pgr_iscolumnindexed(text, text, integer, text) is 'pgRouting internal function';

alter function _pgr_iscolumnindexed(text, text, integer, text) owner to postgres;

