create function pgr_floydwarshall(text, directed boolean DEFAULT true, OUT start_vid bigint, OUT end_vid bigint, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT *
    FROM _pgr_floydWarshall(_pgr_get_statement($1), $2);

$$;

comment on function pgr_floydwarshall(text, boolean, out bigint, out bigint, out double precision) is 'pgr_floydWarshall
- Parameters:
    - edges SQL with columns: source, target, cost [,reverse_cost])
- Optional Parameters:
    - directed := true
- Documentation:
    - https://docs.pgrouting.org/3.1/en/pgr_floydWarshall.html
';

alter function pgr_floydwarshall(text, boolean, out bigint, out bigint, out double precision) owner to postgres;

