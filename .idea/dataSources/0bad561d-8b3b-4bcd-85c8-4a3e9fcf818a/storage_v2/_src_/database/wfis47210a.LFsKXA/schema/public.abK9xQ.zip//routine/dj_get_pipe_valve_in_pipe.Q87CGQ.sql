create function dj_get_pipe_valve_in_pipe(pipe_ftr_idn integer, target_point geometry, previous_ftr_idn_array integer[], envelope geometry) returns text[]
    language plpgsql
as
$$
DECLARE


	row_array_text text;


	result_array text[];


	pip_stt character varying;


BEGIN


	SELECT p.pip_stt INTO pip_stt FROM public.wtl_pipe_lm AS p WHERE p.ftr_idn = pipe_ftr_idn;


	


-- 	RAISE NOTICE 'pipe object 검색, pipe_ftr_idn = %', pipe_ftr_idn;


-- 	RAISE NOTICE 'tartget_point = %', ST_AsText(target_point);


-- 	RAISE NOTICE 'envelope geometry = %', ST_AsText(envelope);


-- 	RAISE NOTICE 'pip_stt = %', pip_stt;





	IF (pip_stt IS NOT NULL OR upper(pip_stt) <> 'NULL') AND pip_stt = '폐관' THEN


-- 		RAISE NOTICE '폐관';


		RETURN result_array;


	END IF;


	


	FOR row_array_text IN


		SELECT ARRAY_TO_STRING(ARRAY[u.type_name::text, u.ftr_idn::text, ST_AsText(u.geom)::text], '|') AS row_array_text FROM


				(


					SELECT 'valve' AS type_name, v.ftr_idn AS ftr_idn, v.geom AS geom


				 	FROM public.wtl_valv_ps AS v


 					WHERE ST_Contains(envelope, v.geom) AND ST_Intersects(ST_Buffer(v.geom, 0.05), target_point)





				UNION


					SELECT 'pipe' AS type_name, p.ftr_idn AS ftr_idn, ST_LineMerge(p.geom) AS geom


					FROM public.wtl_pipe_lm AS p


					WHERE ST_Contains(envelope, p.geom) AND ST_DWithin(p.geom, target_point, 0.0000001) AND p.ftr_idn NOT IN(SELECT(UNNEST(array_sort_unique(previous_ftr_idn_array))))


-- 					WHERE ST_Contains(envelope, p.geom) AND ST_Intersects(p.geom, target_point) AND p.ftr_idn NOT IN(SELECT(UNNEST(array_sort_unique(previous_ftr_idn_array))))


				) AS u


						


	LOOP


		IF row_array_text IS NOT NULL THEN


			result_array := array_append(result_array, row_array_text);


		END IF;


	END LOOP;


	


	RETURN result_array;


END


$$;

alter function dj_get_pipe_valve_in_pipe(integer, geometry, integer[], geometry) owner to postgres;

