create function dj_nearpoint_as_pipe(pipe_ftr_idn integer, selected_x double precision, selected_y double precision) returns geometry
    language plpgsql
as
$$
DECLARE


	pipe_geom geometry;


	near_point geometry;


	temp_near_point geometry;


BEGIN


	SELECT ST_LineMerge(pipe.geom) INTO pipe_geom FROM public.wtl_pipe_lm AS pipe WHERE pipe.ftr_idn = pipe_ftr_idn;


	


	temp_near_point := ST_SetSRID(ST_MakePoint(selected_x, selected_y), 5187);


	


	near_point := ST_ClosestPoint(


			pipe_geom,


			ST_Snap(temp_near_point, pipe_geom, ST_Distance(pipe_geom, temp_near_point) * 1.001)


		);





	RETURN near_point; 


END


$$;

alter function dj_nearpoint_as_pipe(integer, double precision, double precision) owner to postgres;

