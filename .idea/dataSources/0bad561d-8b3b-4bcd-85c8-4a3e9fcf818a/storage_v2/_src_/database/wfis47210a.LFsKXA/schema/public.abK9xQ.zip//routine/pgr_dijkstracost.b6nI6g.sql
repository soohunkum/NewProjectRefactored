create function pgr_dijkstracost(text, bigint, bigint, directed boolean DEFAULT true, OUT start_vid bigint, OUT end_vid bigint, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT start_vid, end_vid, agg_cost
    FROM _pgr_dijkstra(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], ARRAY[$3]::BIGINT[], $4, true);
$$;

comment on function pgr_dijkstracost(text, bigint, bigint, boolean, out bigint, out bigint, out double precision) is 'pgr_dijkstraCost(One to One)
- Parameters:
   - Edges SQL with columns: id, source, target, cost [,reverse_cost]
   - From vertex identifier
   - To vertex identifier
- Optional Parameters
   - directed := true
- Documentation:
   - https://docs.pgrouting.org/3.1/en/pgr_dijkstraCost.html
';

alter function pgr_dijkstracost(text, bigint, bigint, boolean, out bigint, out bigint, out double precision) owner to postgres;

