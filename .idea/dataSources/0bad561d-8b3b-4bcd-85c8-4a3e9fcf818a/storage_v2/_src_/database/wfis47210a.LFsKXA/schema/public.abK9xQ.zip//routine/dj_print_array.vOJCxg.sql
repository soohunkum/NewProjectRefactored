create function dj_print_array(arr text[]) returns void
    language plpgsql
as
$$
DECLARE


BEGIN


-- 	RAISE NOTICE 'PRINT ARRAY';


	


	IF arr IS NULL OR array_length(arr, 1) = 0THEN


-- 		RAISE NOTICE 'ARRAY IS NULL AND 0';


	ELSE


		FOR i IN array_lower(arr, 1) .. array_upper(arr, 1)


		LOOP


			RAISE NOTICE '%', arr[i];


		END LOOP;


	END IF;


	


END


$$;

alter function dj_print_array(text[]) owner to postgres;

