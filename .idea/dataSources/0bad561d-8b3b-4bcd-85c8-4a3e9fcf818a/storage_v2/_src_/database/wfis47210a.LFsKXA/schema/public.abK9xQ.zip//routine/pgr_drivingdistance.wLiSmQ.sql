create function pgr_drivingdistance(text, bigint, double precision, directed boolean DEFAULT true, OUT seq integer, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT seq, node, edge, cost, agg_cost
    FROM _pgr_drivingDistance(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], $3, $4, false);
$$;

comment on function pgr_drivingdistance(text, bigint, double precision, boolean, out integer, out bigint, out bigint, out double precision, out double precision) is 'pgr_drivingDistance(Single_vertex)
- Parameters:
   - Edges SQL with columns: id, source, target, cost [,reverse_cost]
   - From vertex identifier
   - Distance from vertex identifier
- Optional Parameters
   - directed := true
- Documentation:
   - https://docs.pgrouting.org/3.1/en/pgr_drivingDistance.html
';

alter function pgr_drivingdistance(text, bigint, double precision, boolean, out integer, out bigint, out bigint, out double precision, out double precision) owner to postgres;

