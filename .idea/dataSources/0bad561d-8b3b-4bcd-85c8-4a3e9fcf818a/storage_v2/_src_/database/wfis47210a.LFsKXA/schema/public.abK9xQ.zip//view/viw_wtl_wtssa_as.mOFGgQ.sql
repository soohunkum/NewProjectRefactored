create view viw_wtl_wtssa_as (id, geom, 급수분구명, 지형지물부호, 관리번호, 급수구역위치, 급수구역면적, 급수대상인구, 급수분구용량, 급수구역명, 비고) as
SELECT wsb_tb.id,
       wsb_tb.geom,
       wsb_tb.wsb_nam AS "급수분구명",
       wsb_tb.ftr_cde AS "지형지물부호",
       wsb_tb.ftr_idn AS "관리번호",
       wsb_tb.pos_nam AS "급수구역위치",
       wsb_tb.wsg_are AS "급수구역면적",
       wsb_tb.wsg_pop AS "급수대상인구",
       wsb_tb.sol_vol AS "급수분구용량",
       wsb_tb.wsg_nam AS "급수구역명",
       wsb_tb.etc_des AS "비고"
FROM wtl_wtssa_as wsb_tb;

alter table viw_wtl_wtssa_as
    owner to postgres;

