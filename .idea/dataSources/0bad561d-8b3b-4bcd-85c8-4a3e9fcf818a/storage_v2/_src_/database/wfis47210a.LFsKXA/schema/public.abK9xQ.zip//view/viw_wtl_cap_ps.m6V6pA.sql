create view viw_wtl_cap_ps(id, geom, 방향각) as
SELECT wtl_cap_ps.id,
       wtl_cap_ps.geom,
       wtl_cap_ps."방향각"
FROM wtl_cap_ps;

alter table viw_wtl_cap_ps
    owner to postgres;

