create function _pgr_trsp(text, text, bigint, bigint, directed boolean DEFAULT true, OUT seq integer, OUT path_seq integer, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT a.seq, a.path_seq, a.node, a.edge, a.cost, a.agg_cost
        FROM _trsp(
            _pgr_get_statement($1),
            _pgr_get_statement($2),
            ARRAY[$3]::BIGINT[],
            ARRAY[$4]::BIGINT[],
            directed) AS a;
$$;

comment on function _pgr_trsp(text, text, bigint, bigint, boolean, out integer, out integer, out bigint, out bigint, out double precision, out double precision) is 'pgRouting internal function';

alter function _pgr_trsp(text, text, bigint, bigint, boolean, out integer, out integer, out bigint, out bigint, out double precision, out double precision) owner to postgres;

