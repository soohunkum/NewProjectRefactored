create function pgr_withpointsksp(text, text, bigint, bigint, integer, directed boolean DEFAULT true, heap_paths boolean DEFAULT false, driving_side character DEFAULT 'b'::bpchar, details boolean DEFAULT false, OUT seq integer, OUT path_id integer, OUT path_seq integer, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT *
    FROM _pgr_withPointsKSP(_pgr_get_statement($1), _pgr_get_statement($2), $3, $4, $5, $6, $7, $8, $9);
$$;

comment on function pgr_withpointsksp(text, text, bigint, bigint, integer, boolean, boolean, char, boolean, out integer, out integer, out integer, out bigint, out bigint, out double precision, out double precision) is 'pgr_withPointsKSP
- PROPOSED
- Parameters:
    - Edges SQL with columns: id, source, target, cost [,reverse_cost]
    - Points SQL with columns: [pid], edge_id, fraction[,side]
    - From vertex identifier
    - To vertex identifier
    - K
- Optional Parameters
    - directed := true
    - heap paths := false
    - driving side := b
    - details := false
- Documentation:
    - https://docs.pgrouting.org/3.1/en/pgr_withPointsKSP.html
';

alter function pgr_withpointsksp(text, text, bigint, bigint, integer, boolean, boolean, char, boolean, out integer, out integer, out integer, out bigint, out bigint, out double precision, out double precision) owner to postgres;

