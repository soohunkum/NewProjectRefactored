create function dj_re_create_topology() returns void
    language plpgsql
as
$$
DECLARE

BEGIN

	DELETE FROM public.wtl_pipe_lm_topology;

	SELECT setval('public.wtl_pipe_lm_topology_id_seq', 1, false);

	INSERT INTO public.wtl_pipe_lm_topology (id, the_geom) (SELECT id, ST_LineMerge(geom) FROM public.wtl_pipe_lm WHERE pip_stt IS NULL OR pip_stt <> '폐관');



	PERFORM pgr_nodeNetwork('public.wtl_pipe_lm_topology', 0.000001);

	PERFORM pgr_createTopology('public.wtl_pipe_lm_topology_noded', 0.000001, clean:=true);

	PERFORM pgr_analyzegraph('public.wtl_pipe_lm_topology_noded', 0.000001);

END

$$;

alter function dj_re_create_topology() owner to postgres;

