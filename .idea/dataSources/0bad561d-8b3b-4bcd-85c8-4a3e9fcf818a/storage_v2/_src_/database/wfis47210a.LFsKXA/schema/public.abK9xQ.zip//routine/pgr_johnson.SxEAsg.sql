create function pgr_johnson(text, directed boolean DEFAULT true, OUT start_vid bigint, OUT end_vid bigint, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT *
    FROM _pgr_johnson(_pgr_get_statement($1), $2);

$$;

comment on function pgr_johnson(text, boolean, out bigint, out bigint, out double precision) is 'pgr_johnson
- Parameters:
    - edges SQL with columns: source, target, cost [,reverse_cost])
- Optional Parameters:
    - directed := true
- Documentation:
    - https://docs.pgrouting.org/3.1/en/pgr_johnson.html
';

alter function pgr_johnson(text, boolean, out bigint, out bigint, out double precision) owner to postgres;

