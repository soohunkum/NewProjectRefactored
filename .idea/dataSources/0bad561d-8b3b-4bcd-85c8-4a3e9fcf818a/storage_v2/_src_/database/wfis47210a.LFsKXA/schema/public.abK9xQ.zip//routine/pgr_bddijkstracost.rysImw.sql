create function pgr_bddijkstracost(text, bigint, anyarray, directed boolean DEFAULT true, OUT start_vid bigint, OUT end_vid bigint, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT a.start_vid, a.end_vid, a.agg_cost
    FROM _pgr_bdDijkstra(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], $3::BIGINT[], $4, true) as a;
$$;

comment on function pgr_bddijkstracost(text, bigint, anyarray, boolean, out bigint, out bigint, out double precision) is 'pgr_bdDijkstraCost(One to Many)
- Parameters:
  - Edges SQL with columns: id, source, target, cost [,reverse_cost]
  - From vertex identifier
  - To ARRAY[vertices identifiers]
- Optional Parameters
  - directed := true
- Documentation:
  - https://docs.pgrouting.org/3.1/en/pgr_bdDijkstraCost.html
';

alter function pgr_bddijkstracost(text, bigint, anyarray, boolean, out bigint, out bigint, out double precision) owner to postgres;

