create view viw_wtl_wtsba_as (id, geom, 급수블럭명, 관리번호, 급수블럭위치, 급수블럭면적, 급수대상인구, 급수분구용량, 급수구역명, 급수분구명, 비고) as
SELECT wbb_tb.id,
       wbb_tb.geom,
       wbb_tb.wbb_nam AS "급수블럭명",
       wbb_tb.ftr_idn AS "관리번호",
       wbb_tb.pos_nam AS "급수블럭위치",
       wbb_tb.wsg_are AS "급수블럭면적",
       wbb_tb.wsg_pop AS "급수대상인구",
       wbb_tb.sol_vol AS "급수분구용량",
       wbb_tb.wsg_nam AS "급수구역명",
       wbb_tb.wsb_nam AS "급수분구명",
       wbb_tb.etc_des AS "비고"
FROM wtl_wtsba_as wbb_tb;

alter table viw_wtl_wtsba_as
    owner to postgres;

