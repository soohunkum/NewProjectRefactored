create function dj_add_point_line(line_geom geometry, target_line_geom geometry) returns geometry
    language plpgsql
as
$$
DECLARE

	i integer;

	vertex geometry;

BEGIN

	i := 1;

	FOR vertex IN SELECT (ST_DumpPoints(target_line_geom)).geom

	LOOP

		IF i = 1 THEN

			IF NOT ST_Intersects(ST_Buffer(ST_EndPoint(line_geom), 0.0001), vertex) THEN

				line_geom := ST_AddPoint(line_geom, vertex);

			END IF;

		ELSE

			line_geom := ST_AddPoint(line_geom, vertex);

		END IF;

		

		i := i + 1;

	END LOOP;

	

	RETURN line_geom;

END

$$;

alter function dj_add_point_line(geometry, geometry) owner to postgres;

