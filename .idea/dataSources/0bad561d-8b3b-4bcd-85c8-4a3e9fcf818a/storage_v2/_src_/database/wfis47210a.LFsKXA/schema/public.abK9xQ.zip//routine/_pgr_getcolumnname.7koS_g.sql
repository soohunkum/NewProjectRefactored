create function _pgr_getcolumnname(tab text, col text, reporterrs integer DEFAULT 1, fnname text DEFAULT '_pgr_getColumnName'::text) returns text
    strict
    language plpgsql
as
$$
DECLARE
    sname text;
    tname text;
    cname text;
    naming record;
    err boolean;
BEGIN
    select * into naming from _pgr_getTableName(tab,reportErrs, fnName) ;
    sname=naming.sname;
    tname=naming.tname;

    select * into cname from _pgr_getColumnName(sname,tname,col,reportErrs, fnName);
    RETURN cname;
END;

$$;

comment on function _pgr_getcolumnname(text, text, integer, text) is 'pgRouting internal function';

alter function _pgr_getcolumnname(text, text, integer, text) owner to postgres;

