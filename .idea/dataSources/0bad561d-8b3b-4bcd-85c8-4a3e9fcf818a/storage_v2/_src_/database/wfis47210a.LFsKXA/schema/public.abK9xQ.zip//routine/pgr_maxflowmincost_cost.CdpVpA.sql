create function pgr_maxflowmincost_cost(text, anyarray, bigint) returns double precision
    language sql
as
$$
SELECT cost
    FROM _pgr_maxFlowMinCost(_pgr_get_statement($1), $2::BIGINT[], ARRAY[$3]::BIGINT[], only_cost := true);
$$;

comment on function pgr_maxflowmincost_cost(text, anyarray, bigint) is 'pgr_maxFlowMinCost_Cost (Many to One)
- EXPERIMENTAL
- Parameters:
  - Edges SQL with columns: id, source, target, cost [,reverse_cost]
  - From ARRAY[vertices identifiers]
  - To vertex identifier
- Documentation:
  - https://docs.pgrouting.org/3.1/en/pgr_maxFlowMinCost_Cost.html
';

alter function pgr_maxflowmincost_cost(text, anyarray, bigint) owner to postgres;

