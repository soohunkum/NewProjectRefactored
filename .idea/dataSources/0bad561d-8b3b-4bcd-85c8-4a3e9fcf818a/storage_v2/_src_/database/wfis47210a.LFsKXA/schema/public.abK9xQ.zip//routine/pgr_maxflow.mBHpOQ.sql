create function pgr_maxflow(text, bigint, anyarray) returns bigint
    strict
    language sql
as
$$
SELECT flow
        FROM _pgr_maxflow(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], $3::BIGINT[], algorithm := 1, only_flow := true);
$$;

comment on function pgr_maxflow(text, bigint, anyarray) is 'pgr_maxFlow(One to Many)
- Directed graph
- Parameters:
  - edges SQL with columns: id, source, target, capacity [,reverse_capacity]
  - from vertex
  - to ARRAY[vertices identifiers]
- Documentation:
  - https://docs.pgrouting.org/3.1/en/pgr_maxFlow.html
';

alter function pgr_maxflow(text, bigint, anyarray) owner to postgres;

