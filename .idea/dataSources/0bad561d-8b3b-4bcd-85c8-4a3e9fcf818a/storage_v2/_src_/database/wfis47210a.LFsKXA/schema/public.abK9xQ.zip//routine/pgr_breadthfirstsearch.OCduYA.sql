create function pgr_breadthfirstsearch(text, bigint, max_depth bigint DEFAULT '9223372036854775807'::bigint, directed boolean DEFAULT true, OUT seq bigint, OUT depth bigint, OUT start_vid bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language plpgsql
as
$$
BEGIN
    IF $3 < 0 THEN
        RAISE EXCEPTION 'Negative value found on ''max_depth'''
        USING HINT = format('Value found: %s', $3);
    END IF;


    RETURN QUERY
    SELECT *
    FROM _pgr_breadthFirstSearch(_pgr_get_statement($1),  ARRAY[$2]::BIGINT[], max_depth, directed) AS a;
END;
$$;

comment on function pgr_breadthfirstsearch(text, bigint, bigint, boolean, out bigint, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgr_breadthFirstSearch(One to Depth)
- EXPERIMENTAL
- Parameters:
  - edges SQL with columns: id, source, target, cost [,reverse_cost]
  - From vertex identifier
- Optional Parameters: 
  - Maximum Depth := 9223372036854775807
  - directed := true
- Documentation:
  - https://docs.pgrouting.org/3.1/en/pgr_breadthFirstSearch.html
';

alter function pgr_breadthfirstsearch(text, bigint, bigint, boolean, out bigint, out bigint, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

