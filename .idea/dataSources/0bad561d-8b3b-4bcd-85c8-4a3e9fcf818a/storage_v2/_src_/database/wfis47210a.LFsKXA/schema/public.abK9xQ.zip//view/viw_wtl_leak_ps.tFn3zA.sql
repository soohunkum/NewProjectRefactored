create view viw_wtl_leak_ps
            (레이어, 관리번호, 민원접수번호, 누수일자, 누수위치설명, 관재질, 관구경, 누수원인, 누수부위, 누수현황, 복구일자, 누수복구내용, 소요자재내역, 누수복구자명, 읍면동, 법정동, 도엽번호,
             상수관로관리번호) as
SELECT '누수지점'::text    AS "레이어",
       leak_tb.ftr_idn AS "관리번호",
       leak_tb.rcv_num AS "민원접수번호",
       leak_tb.lek_ymd AS "누수일자",
       leak_tb.lek_loc AS "누수위치설명",
       mop_tb.cname_sl AS "관재질",
       leak_tb.pip_dip AS "관구경",
       lrs_tb.cname    AS "누수원인",
       lep_tb.cname    AS "누수부위",
       leak_tb.lek_exp AS "누수현황",
       leak_tb.rep_ymd AS "복구일자",
       leak_tb.rep_exp AS "누수복구내용",
       leak_tb.mat_des AS "소요자재내역",
       leak_tb.rep_nam AS "누수복구자명",
       bjd_tb.hjd_nam  AS "읍면동",
       bjd_tb.bjd_nam  AS "법정동",
       leak_tb.sht_num AS "도엽번호",
       leak_tb.pip_idn AS "상수관로관리번호"
FROM wtl_leak_ps leak_tb
         LEFT JOIN bml_badm_as bjd_tb ON leak_tb.bjd_cde = bjd_tb.bjd_cde
         LEFT JOIN private.cd_mop mop_tb ON leak_tb.pip_mop = mop_tb.codeno AND mop_tb.tbl_nam = '관재질'::bpchar
         LEFT JOIN private.cd_lrs lrs_tb ON leak_tb.lrs_cde = lrs_tb.codeno
         LEFT JOIN private.cd_lep lep_tb ON leak_tb.lep_cde = lep_tb.codeno;

alter table viw_wtl_leak_ps
    owner to postgres;

