create function pgr_edmondskarp(text, anyarray, bigint, OUT seq integer, OUT edge bigint, OUT start_vid bigint, OUT end_vid bigint, OUT flow bigint, OUT residual_capacity bigint) returns SETOF record
    strict
    language sql
as
$$
SELECT *
        FROM _pgr_maxflow(_pgr_get_statement($1), $2::BIGINT[], ARRAY[$3]::BIGINT[], 3);
$$;

comment on function pgr_edmondskarp(text, anyarray, bigint, out integer, out bigint, out bigint, out bigint, out bigint, out bigint) is 'pgr_edmondsKarp(Many to One)
- Directed graph
- Parameters:
  - Edges SQL with columns: id, source, target, capacity [,reverse_capacity]
  - From ARRAY[vertices identifiers]
  - to vertex
- Documentation:
  - https://docs.pgrouting.org/3.1/en/pgr_edmondsKarp.html
';

alter function pgr_edmondskarp(text, anyarray, bigint, out integer, out bigint, out bigint, out bigint, out bigint, out bigint) owner to postgres;

