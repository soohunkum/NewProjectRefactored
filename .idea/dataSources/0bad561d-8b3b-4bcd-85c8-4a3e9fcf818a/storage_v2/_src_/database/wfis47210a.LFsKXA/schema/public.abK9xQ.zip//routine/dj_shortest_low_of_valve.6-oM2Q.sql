create function dj_shortest_low_of_valve(pipe_ftr_idn integer, selected_x double precision, selected_y double precision, distance double precision)
    returns TABLE(path_length double precision, path_geom geometry, point_layer character varying, point_ftr_idn integer, point_geom geometry)
    language plpgsql
as
$$
DECLARE

BEGIN

	FOR path_length, path_geom, point_layer, point_ftr_idn, point_geom IN

		(

		SELECT * FROM public.dj_shortest_point('public.wtl_fire_ps', pipe_ftr_idn, selected_x, selected_y, distance, '소화전')

		UNION ALL

		SELECT * FROM public.dj_shortest_point('public.wtl_valv_ps', pipe_ftr_idn, selected_x, selected_y, distance, '이토변')

		 ) ORDER BY path_length

	LOOP

		RETURN NEXT;

	END LOOP;

END

$$;

alter function dj_shortest_low_of_valve(integer, double precision, double precision, double precision) owner to postgres;

