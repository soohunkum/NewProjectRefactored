create function _pgr_array_reverse(anyarray) returns anyarray
    immutable
    strict
    language sql
as
$$
SELECT ARRAY(
    SELECT $1[i]
    FROM generate_subscripts($1,1) AS s(i)
    ORDER BY i DESC
);
$$;

comment on function _pgr_array_reverse(anyarray) is 'pgRouting internal function';

alter function _pgr_array_reverse(anyarray) owner to postgres;

