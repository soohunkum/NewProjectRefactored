create function pgr_full_version(OUT version text, OUT build_type text, OUT compile_date text, OUT library text, OUT system text, OUT postgresql text, OUT compiler text, OUT boost text, OUT hash text) returns record
    immutable
    language sql
as
$$
SELECT pgr_version(),
        _pgr_build_type(),
        _pgr_compilation_date(),
        _pgr_lib_version(),
        _pgr_operating_system(),
        _pgr_pgsql_version(),
        _pgr_compiler_version(),
        _pgr_boost_version(),
        _pgr_git_hash()
$$;

comment on function pgr_full_version(out text, out text, out text, out text, out text, out text, out text, out text, out text) is 'pgr_full_version
- Documentation
  - https://docs.pgrouting.org/3.1/en/pgr_full_version.html
';

alter function pgr_full_version(out text, out text, out text, out text, out text, out text, out text, out text, out text) owner to postgres;

