create function dj_dijkstra_and_calibrate(source_point geometry, source_id integer, target_id integer, selected_point geometry, pipe_geom geometry) returns geometry
    language plpgsql
as
$$
DECLARE

	node_geom geometry;

	calibrated_geom geometry;

BEGIN

	RAISE INFO 'start_id = %', source_id;

	RAISE INFO 'start_point = %', ST_AsText(source_point);

	RAISE INFO 'target_id = %', target_id;

	

	node_geom := dj_dijkstra(source_point, source_id, target_id);

	

	IF node_geom IS NULL THEN

		RETURN NULL;

	ELSE

		RETURN  dj_dijkstra_calibrate(node_geom, selected_point, pipe_geom);	

	END IF;

END

$$;

alter function dj_dijkstra_and_calibrate(geometry, integer, integer, geometry, geometry) owner to postgres;

