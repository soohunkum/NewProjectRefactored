create view viw_wtl_taper_ps(id, geom, 방향각) as
SELECT wtl_taper_ps.id,
       wtl_taper_ps.geom,
       wtl_taper_ps."방향각"
FROM wtl_taper_ps;

alter table viw_wtl_taper_ps
    owner to postgres;

