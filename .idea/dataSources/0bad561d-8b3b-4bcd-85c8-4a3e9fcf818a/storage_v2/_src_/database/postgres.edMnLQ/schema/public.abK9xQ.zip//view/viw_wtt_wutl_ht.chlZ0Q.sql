create view viw_wtt_wutl_ht (geom, 급수구역, 시설물구분, 관리번호, 유지보수일자, 유지보수구분, 유지보수사유, 유지보수내용, 시공자명, 읍면동, 법정동, 레이어) as
SELECT ms.geom,
       swb.wsb_nam  AS "급수구역",
       sft.cname    AS "시설물구분",
       ms.ftr_idn   AS "관리번호",
       ms.rep_ymd   AS "유지보수일자",
       sep.cname    AS "유지보수구분",
       ssb.cname    AS "유지보수사유",
       ms.rep_des   AS "유지보수내용",
       ms.opr_nam   AS "시공자명",
       sbj.hjd_nam  AS "읍면동",
       sbj.bjd_nam  AS "법정동",
       '보수공사'::text AS "레이어"
FROM wtt_wutl_ht ms
         LEFT JOIN private.cd_ftr sft ON ms.ftr_cde = sft.codeno
         LEFT JOIN private.cd_rep sep ON ms.rep_cde = sep.codeno
         LEFT JOIN private.cd_sbj ssb ON ms.sbj_cde = ssb.codeno
         LEFT JOIN bml_badm_as sbj ON ms.bjd_cde = sbj.bjd_cde
         LEFT JOIN wtl_wtssa_as swb ON ms.wsb_cde = swb.wsb_cde;

alter table viw_wtt_wutl_ht
    owner to postgres;

