create view viw_wtl_manh_ps
            (id, geom, 레이어, 관리번호, 급수구역, 규격, 맨홀종류, 맨홀형태, 읍면동, 법정동, 급수분구, 급수블럭, 설치일자, 공사명, 관리기관, 도엽번호, 방향각) as
SELECT manh_tb.id,
       manh_tb.geom,
       btrim(manh_tb.layer::text) AS "레이어",
       manh_tb.ftr_idn            AS "관리번호",
       wsg_tb.wsg_nam             AS "급수구역",
       manh_tb.man_std            AS "규격",
       som_tb.cname               AS "맨홀종류",
       mhs_tb.cname               AS "맨홀형태",
       bjd_tb.hjd_nam             AS "읍면동",
       bjd_tb.bjd_nam             AS "법정동",
       wsb_tb.wsb_nam             AS "급수분구",
       wbb_tb.wbb_nam             AS "급수블럭",
       manh_tb.ist_ymd            AS "설치일자",
       manh_tb.cnt_num            AS "공사명",
       mng_tb.cname               AS "관리기관",
       manh_tb.sht_num            AS "도엽번호",
       manh_tb.ang_dir            AS "방향각"
FROM wtl_manh_ps manh_tb
         LEFT JOIN wtl_wtsa_as wsg_tb ON manh_tb.wsg_cde = wsg_tb.wsg_cde
         LEFT JOIN wtl_wtssa_as wsb_tb ON manh_tb.wsb_cde = wsb_tb.wsb_cde
         LEFT JOIN wtl_wtsba_as wbb_tb ON manh_tb.wbb_cde = wbb_tb.wbb_cde
         LEFT JOIN bml_badm_as bjd_tb ON manh_tb.bjd_cde = bjd_tb.bjd_cde
         LEFT JOIN private.cd_mng mng_tb ON manh_tb.mng_cde = mng_tb.codeno
         LEFT JOIN private.cd_som som_tb ON manh_tb.som_cde = som_tb.codeno
         LEFT JOIN private.cd_mhs mhs_tb ON manh_tb.mhs_cde = mhs_tb.codeno;

alter table viw_wtl_manh_ps
    owner to postgres;

