create view viw_bml_hadm_as(id, geom, 행정동) as
SELECT bml_hadm_as.id,
       bml_hadm_as.geom,
       bml_hadm_as.hjd_nam AS "행정동"
FROM bml_hadm_as;

alter table viw_bml_hadm_as
    owner to postgres;

