create function pgr_drivingdistance(text, anyarray, double precision, directed boolean DEFAULT true, equicost boolean DEFAULT false, OUT seq integer, OUT from_v bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT *
    FROM _pgr_drivingDistance(_pgr_get_statement($1), $2, $3, $4, $5);
$$;

comment on function pgr_drivingdistance(text, anyarray, double precision, boolean, boolean, out integer, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgr_drivingDistance(Multiple vertices)
- Parameters:
   - Edges SQL with columns: id, source, target, cost [,reverse_cost]
   - From ARRAY[vertices identifiers]
   - Distance from vertices identifiers
- Optional Parameters
   - directed := true
   - equicost := false
- Documentation:
   - https://docs.pgrouting.org/3.1/en/pgr_drivingDistance.html
';

alter function pgr_drivingdistance(text, anyarray, double precision, boolean, boolean, out integer, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

