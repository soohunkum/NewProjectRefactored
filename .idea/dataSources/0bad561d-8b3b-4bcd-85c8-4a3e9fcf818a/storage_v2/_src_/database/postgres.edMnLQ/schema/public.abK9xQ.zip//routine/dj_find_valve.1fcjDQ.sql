create function dj_find_valve(pipe_array text[], previous_pipe_geom geometry, previous_ftr_idn_array integer[]) returns text[]
    language plpgsql
as
$$
DECLARE


	split_array text[];


	valve_array text[];


	pipe_ftr_idn integer;


	pipe_geom geometry;


BEGIN


--   	RAISE NOTICE 'dj_find_valve';


--   	PERFORM dj_print_array(pipe_array);


	


-- 	RAISE NOTICE 'previous_pipe_geom : %', ST_AsText(previous_pipe_geom);


	


	FOR i IN array_lower(pipe_array, 1) .. array_upper(pipe_array, 1)


	LOOP


		split_array := string_to_array(pipe_array[i], '|');


		


		pipe_ftr_idn := CAST(split_array[2] AS integer);


--  		RAISE NOTICE 'pipe_ftr_idn : %', pipe_ftr_idn;


		pipe_geom := ST_LineFromText(split_array[3], 5187);


		


-- 		RAISE NOTICE 'start_pipe_geom : %', ST_AsText(ST_StartPoint(pipe_geom));


-- 		RAISE NOTICE 'end_pipe_geom : %', ST_AsText(ST_EndPoint(pipe_geom));


		


		IF ST_Intersects(previous_pipe_geom, ST_Buffer(ST_StartPoint(pipe_geom), 0.05)) THEN


-- 			RAISE NOTICE '% = dj_find_Start_Point', pipe_ftr_idn;


			valve_array := valve_array ||


				dj_search_vertex_in_pipe(pipe_ftr_idn, ST_StartPoint(pipe_geom), ST_EndPoint(pipe_geom), previous_ftr_idn_array);


		ELSEIF ST_Intersects(previous_pipe_geom, ST_Buffer(ST_EndPoint(pipe_geom), 0.05)) THEN


-- 			RAISE NOTICE '% = dj_find_End_Point', pipe_ftr_idn;


			valve_array := valve_array ||


				dj_search_vertex_in_pipe(pipe_ftr_idn, ST_EndPoint(pipe_geom), ST_StartPoint(pipe_geom), previous_ftr_idn_array);


		ELSE


-- 			RAISE NOTICE '% = dj_find_Middle_Point', pipe_ftr_idn;


-- 			raise notice 'previous_pipe_geom_End_Point = %', ST_AsText(ST_EndPoint(previous_pipe_geom));


			valve_array := valve_array ||


				dj_search_vertex_in_pipe(pipe_ftr_idn, ST_EndPoint(previous_pipe_geom), ST_StartPoint(pipe_geom), previous_ftr_idn_array);


			valve_array := valve_array ||


				dj_search_vertex_in_pipe(pipe_ftr_idn, ST_EndPoint(previous_pipe_geom), ST_EndPoint(pipe_geom), previous_ftr_idn_array);


		END IF;


		


	END LOOP;


	


	RETURN valve_array;


END


$$;

alter function dj_find_valve(text[], geometry, integer[]) owner to postgres;

