create view viw_bml_badm_as(id, geom, 행정동, 법정동) as
SELECT bml_badm_as.id,
       bml_badm_as.geom,
       bml_badm_as.hjd_nam AS "행정동",
       bml_badm_as.bjd_nam AS "법정동"
FROM bml_badm_as;

alter table viw_bml_badm_as
    owner to postgres;

