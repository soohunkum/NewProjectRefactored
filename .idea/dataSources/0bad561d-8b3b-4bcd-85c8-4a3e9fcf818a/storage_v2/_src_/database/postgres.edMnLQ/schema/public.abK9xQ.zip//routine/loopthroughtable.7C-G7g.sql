create function loopthroughtable() returns void
    language plpgsql
as
$$
DECLARE

    t_row wtt_wser_ma%rowtype;

BEGIN

    FOR t_row in SELECT * FROM wtt_wser_ma LOOP

        if t_row.rcv_num is null

        then

            update wtt_wser_ma

            set t_row.rcv_num = dj_yearly_counter()

            where id = t_row.id; --<<< !!! important !!!

        end if;

        END LOOP;

END;

$$;

alter function loopthroughtable() owner to postgres;

