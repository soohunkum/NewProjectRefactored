create function dj_dijkstra(source_point geometry, source_id integer, target_id integer) returns geometry
    language plpgsql
as
$$
DECLARE

	node_geom geometry;

BEGIN			

--  	SELECT ST_Union(Array_agg(n.the_geom)) INTO node_geom FROM (SELECT * FROM pgr_dijkstra(

--  		'SELECT id, source, target, st_length(the_geom) as cost, st_length(the_geom) as reverse_cost FROM public.wtl_pipe_lm_topology_noded',

--  		source_id, target_id, directed:=false) AS d

--  		LEFT JOIN public.wtl_pipe_lm_topology_noded_vertices_pgr AS v ON d.node = v.id ORDER BY d.agg_cost ASC) AS r LEFT JOIN wtl_pipe_lm_topology_noded AS n ON r.edge = n.id;

	

--  	SELECT ST_Union(Array_agg(n.the_geom)) INTO node_geom FROM (SELECT * FROM pgr_dijkstra(

--  		'SELECT id, source, target, st_length(the_geom) as cost, st_length(the_geom) as reverse_cost FROM public.wtl_pipe_lm_topology_noded',

--  		source_id, target_id, directed:=false) AS d

--  		LEFT JOIN public.wtl_pipe_lm_topology_noded_vertices_pgr AS v ON d.node = v.id) AS r LEFT JOIN wtl_pipe_lm_topology_noded AS n ON r.edge = n.id;

		

-- 	SELECT ST_Collect(Array_agg(g.the_geom)) INTO node_geom FROM (SELECT * FROM pgr_dijkstra(

--  		'SELECT id, source, target, st_length(the_geom) as cost, st_length(the_geom) as reverse_cost FROM public.wtl_pipe_lm_topology_noded',

--  		source_id, target_id, directed:=false) AS d

--  		LEFT JOIN wtl_pipe_lm_topology_noded AS n ON d.edge = n.id ORDER BY d.agg_cost) AS g;

		

	SELECT ST_Collect(Array_agg(n.the_geom)) INTO node_geom FROM pgr_dijkstra(

 		'SELECT id, source, target, st_length(the_geom) as cost, st_length(the_geom) as reverse_cost FROM public.wtl_pipe_lm_topology_noded',

 		source_id, target_id, directed:=false) AS d

 		LEFT JOIN wtl_pipe_lm_topology_noded AS n ON d.edge = n.id;

		

	RAISE INFO 'dijkstra node_geom = %', ST_AsText(node_geom);

	

	IF node_geom IS NULL THEN

		RETURN NULL;

	END IF;

	

	node_geom := ST_LineMerge(ST_SnapToGrid(node_geom, 0.000000001));

-- 	node_geom := dj_convert_multiline(node_geom, source_point);



	RAISE INFO 'ST_LineMerge node_geom = %', ST_AsText(node_geom);

	

	IF NOT ST_Intersects(ST_Buffer(ST_StartPoint(node_geom), 0.0001), source_point) THEN

		RAISE INFO 'node_geom reverse';

		node_geom := ST_Reverse(node_geom);

	END IF;

	

	IF POSITION('Multi' IN ST_GeometryType(node_geom)) > 0 THEN

		RAISE INFO 'multi convert to linestring';

		node_geom := dj_convert_multiline(node_geom, source_point);

	END IF;

	

	RETURN node_geom;

END

$$;

alter function dj_dijkstra(geometry, integer, integer) owner to postgres;

