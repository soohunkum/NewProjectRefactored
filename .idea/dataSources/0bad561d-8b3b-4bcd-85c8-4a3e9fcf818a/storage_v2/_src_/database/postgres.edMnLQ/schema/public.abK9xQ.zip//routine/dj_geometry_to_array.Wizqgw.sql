create function dj_geometry_to_array(geom geometry) returns geometry[]
    language plpgsql
as
$$
DECLARE

	output_geom geometry;

	geom_array geometry[];

BEGIN

	FOR output_geom IN SELECT (a.p_geom).geom As output_geom

  		FROM (SELECT ST_Dump(geom) AS p_geom ) AS a

	LOOP

 		geom_array := geom_array || ST_MakeLine(output_geom); 

	END LOOP;

	

	RETURN geom_array;

END

$$;

alter function dj_geometry_to_array(geometry) owner to postgres;

