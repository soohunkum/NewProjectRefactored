create function dj_search_vertex_in_pipe(pipe_ftr_idn integer, start_point geometry, end_point geometry, previous_ftr_idn_array integer[]) returns text[]
    language plpgsql
as
$$
DECLARE


	pipe_geom geometry;


	pipe_verteces geometry[];


	pipe_vertex geometry;


	old_point geometry;


	current_point geometry;


	temp_line_verteces geometry[];


	temp_line geometry;


	temp_point geometry;


	is_intersects boolean;


	temp_start_point geometry;


	is_valid_line boolean;


	result_array text[];


	valve_array text[];


	pipe_array text[];


	re_search_pipe_array text[];


	envelope geometry;


BEGIN


-- 	RAISE NOTICE 'current pipe = %', pipe_ftr_idn;


-- 	raise notice 'start_point = %', ST_AsText(start_point);


-- 	raise notice 'end_point = %', ST_AsText(end_point);


-- 	raise notice 'previous_ftr_idn = %', previous_ftr_idn;


	


	SELECT ST_LineMerge(pipe.geom) INTO pipe_geom FROM public.wtl_pipe_lm AS pipe WHERE pipe.ftr_idn = pipe_ftr_idn;


	


	previous_ftr_idn_array := array_append(previous_ftr_idn_array, pipe_ftr_idn);


	


	SELECT ST_Buffer(ST_Envelope(ST_Union(u.geom)), 5, 'endcap=square join=mitre') into envelope FROM


	(SELECT p2.geom AS geom FROM


	 	(SELECT sp.* FROM public.wtl_pipe_lm AS sp WHERE sp.ftr_idn = pipe_ftr_idn) AS p1, public.wtl_pipe_lm AS p2


				WHERE st_intersects(p1.geom, p2.geom)


	UNION


		SELECT v.geom AS geom FROM


	 		(SELECT sp.* FROM public.wtl_valv_ps AS sp WHERE sp.ftr_idn = pipe_ftr_idn) AS p, public.wtl_valv_ps AS v


		WHERE st_intersects(v.geom, p.geom)) AS u;


	


-- 	raise notice 'current_pipe_geom = %', ST_AsText(pipe_geom);


-- 	raise notice 'pipe_start_point = %', ST_AsText(ST_StartPoint(pipe_geom));


-- 	raise notice 'Reverse Check % = % : %', ST_AsText(ST_MakePoint(ST_X(ST_StartPoint(pipe_geom)), ST_Y(ST_StartPoint(pipe_geom)))), ST_AsText(end_point),  ST_Equals(


--  		ST_MakePoint(ST_X(ST_StartPoint(pipe_geom)), ST_Y(ST_StartPoint(pipe_geom))),


--  		ST_MakePoint(ST_X(end_point), ST_Y(end_point))


--  	);


	


	IF ST_Equals(


		ST_SnapToGrid(


			end_point, 0.0001


		),


		ST_SnapToGrid(


			ST_StartPoint(pipe_geom), 0.0001


		)


	) THEN


-- 		raise notice 'reverse';


		pipe_geom := ST_Reverse(pipe_geom);


	END IF;


	


	FOR pipe_vertex IN SELECT (ST_DumpPoints(pipe_geom)).geom


	LOOP


		pipe_verteces := array_append(pipe_verteces, pipe_vertex);


	END LOOP;


	


	temp_start_point := ST_SetSRID(ST_MakePoint(212046.9716, 367897.7407, 0), 5187);


		


	temp_point := ST_SetSRID(ST_MakePoint(ST_X(start_point), ST_Y(start_point), 0), 5187);


-- 	raise notice 'temp_point = %', ST_AsText(temp_point);


	


	is_valid_line := false;


	FOR i IN array_lower(pipe_verteces, 1) .. array_upper(pipe_verteces, 1)


	LOOP


		old_point := current_point;


		current_point := pipe_verteces[i];





-- 		temp_line_verteces := array_append(temp_line_verteces, pipe_verteces[i]);





		CONTINUE WHEN old_point IS NULL;





		temp_line := ST_MakeLine(old_point, current_point);


--			temp_line := ST_MakeLine(temp_line_verteces);





-- 		raise notice 'check_line = %', ST_AsText(temp_line);





		is_intersects := ST_DWithin(temp_line, temp_point, 0.0001);





		IF (NOT is_valid_line AND is_intersects) THEN


			is_valid_line := true;


		END IF;


		


		CONTINUE WHEN NOT is_valid_line;


		


-- 		RAISE NOTICE 'EXECUTE POINT = %', ST_AsText(current_point);


		


 		result_array := dj_get_pipe_valve_in_pipe(pipe_ftr_idn, current_point, previous_ftr_idn_array, envelope);


-- 		RAISE NOTICE 'result_array = %', result_array;


--   	PERFORM dj_print_array(result_array);


		


		valve_array := dj_get_type_array(result_array, 'valve');


		


-- 		RAISE NOTICE 'print valve';


-- 		PERFORM dj_print_array(valve_array);


		


		EXIT WHEN array_length(valve_array, 1) > 0;


		


		pipe_array := dj_get_type_array(result_array, 'pipe');


		


		re_search_pipe_array := re_search_pipe_array || pipe_array;


		


-- 		RAISE NOTICE 'print pipe';


-- 		PERFORM dj_print_array(pipe_array);


		


-- 		IF array_length(pipe_array, 1) > 0 THEN


-- 			re_search_pipe_array := re_search_pipe_array || pipe_array;


-- 		END IF;


		


	END LOOP;


	


	IF array_length(re_search_pipe_array, 1) > 0 THEN


		valve_array := valve_array || dj_find_valve(re_search_pipe_array, pipe_geom, previous_ftr_idn_array);


	END IF;


	


	RETURN valve_array;


	


END


$$;

alter function dj_search_vertex_in_pipe(integer, geometry, geometry, integer[]) owner to postgres;

