create function dj_dijkstra_calibrate(node_geom geometry, selected_point geometry, pipe_geom geometry) returns geometry
    language plpgsql
as
$$
DECLARE

	calibrated_geom geometry;

	split_geom geometry;

BEGIN

	RAISE INFO 'node_geom = %', ST_AsText(node_geom);

	BEGIN

-- 		IF ST_Intersects(ST_Buffer(node_geom, 0.0001), pipe_geom) THEN

		IF ST_Contains(ST_Buffer(node_geom, 0.0001), pipe_geom) THEN

			RAISE INFO 'node_geom intersects pipe_geom';

			IF ST_DWithin(node_geom, selected_point, 0.0000001) THEN

				RAISE INFO 'node_geom intersects selected_point';

				calibrated_geom := ST_LineSubstring(

					node_geom,

					ST_LineLocatePoint(node_geom, selected_point),

					ST_LineLocatePoint(node_geom, ST_EndPoint(node_geom))

				);

			ELSE

				RAISE INFO 'node_geom not intersects selected_point';

			END IF;

		ELSE

			RAISE INFO 'node_geom not intersects pipe_geom';

			IF ST_DWithin(node_geom, ST_StartPoint(pipe_geom), 0.0000001) THEN

				split_geom := ST_LineSubstring(

					pipe_geom,

					0,

					ST_LineLocatePoint(pipe_geom, selected_point)

				);

			ELSE

				split_geom := ST_LineSubstring(

					pipe_geom,

					ST_LineLocatePoint(pipe_geom, selected_point),

					ST_LineLocatePoint(pipe_geom, ST_EndPoint(pipe_geom))

				);

			END IF;

					

			calibrated_geom := ST_Union(node_geom, split_geom);

		END IF;

	EXCEPTION WHEN others THEN

		RETURN NULL;

	END;

		

	RETURN calibrated_geom;

END

$$;

alter function dj_dijkstra_calibrate(geometry, geometry, geometry) owner to postgres;

