create function array_sort_unique(anyarray) returns anyarray
    language sql
as
$$
SELECT ARRAY(


    SELECT DISTINCT $1[s.i]


    FROM generate_series(array_lower($1,1), array_upper($1,1)) AS s(i)


    ORDER BY 1


  );


$$;

alter function array_sort_unique(anyarray) owner to postgres;

