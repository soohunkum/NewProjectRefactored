create function pgr_binarybreadthfirstsearch(text, bigint, anyarray, directed boolean DEFAULT true, OUT seq integer, OUT path_seq integer, OUT end_vid bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT a.seq, a.path_seq, a.end_vid, a.node, a.edge, a.cost, a.agg_cost
    FROM _pgr_binaryBreadthFirstSearch(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], $3::BIGINT[], $4) AS a;
$$;

comment on function pgr_binarybreadthfirstsearch(text, bigint, anyarray, boolean, out integer, out integer, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgr_binaryBreadthFirstSearch(One to Many)
- Parameters:
   - Edges SQL with columns: id, source, target, cost [,reverse_cost]
   - From vertex identifier
   - To ARRAY[vertices identifiers]
- Optional Parameters
   - directed := true
- Documentation:
   - https://docs.pgrouting.org/3.1/en/pgr_binaryBreadthFirstSearch.html
';

alter function pgr_binarybreadthfirstsearch(text, bigint, anyarray, boolean, out integer, out integer, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

