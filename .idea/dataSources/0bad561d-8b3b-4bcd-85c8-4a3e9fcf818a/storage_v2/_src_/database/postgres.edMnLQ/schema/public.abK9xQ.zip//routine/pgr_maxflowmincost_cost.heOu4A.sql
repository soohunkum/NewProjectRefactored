create function pgr_maxflowmincost_cost(text, bigint, anyarray) returns double precision
    language sql
as
$$
SELECT cost
    FROM _pgr_maxFlowMinCost(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], $3::BIGINT[], only_cost := true);
$$;

comment on function pgr_maxflowmincost_cost(text, bigint, anyarray) is 'pgr_maxFlowMinCost_Cost(One to Many)
- EXPERIMENTAL
- Parameters:
  - Edges SQL with columns: id, source, target, cost [,reverse_cost]
  - From vertex identifier
  - To ARRAY[vertices identifiers]
- Documentation:
  - https://docs.pgrouting.org/3.1/en/pgr_maxFlowMinCost_Cost.html
  ';

alter function pgr_maxflowmincost_cost(text, bigint, anyarray) owner to postgres;

