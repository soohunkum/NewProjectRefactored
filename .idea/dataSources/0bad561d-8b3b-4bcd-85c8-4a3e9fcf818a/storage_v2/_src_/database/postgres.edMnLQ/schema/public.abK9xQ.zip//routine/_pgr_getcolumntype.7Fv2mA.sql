create function _pgr_getcolumntype(sname text, tname text, cname text, reporterrs integer DEFAULT 0, fnname text DEFAULT '_pgr_getColumnType'::text) returns text
    strict
    language plpgsql
as
$$
DECLARE
    ctype text;
    naming record;
    err boolean;
BEGIN

    EXECUTE 'select data_type  from information_schema.columns '
            || 'where table_name = '||quote_literal(tname)
                 || ' and table_schema=' || quote_literal(sname)
                 || ' and column_name='||quote_literal(cname)
       into ctype;
    err = ctype is null;
    perform _pgr_onError(err, reportErrs, fnName,
            'Type of Column '|| cname ||' not found',
            'Check your column name',
            'OK: Type of Column '|| cname || ' is ' || ctype);
    RETURN ctype;
END;

$$;

comment on function _pgr_getcolumntype(text, text, text, integer, text) is 'pgRouting internal function';

alter function _pgr_getcolumntype(text, text, text, integer, text) owner to postgres;

