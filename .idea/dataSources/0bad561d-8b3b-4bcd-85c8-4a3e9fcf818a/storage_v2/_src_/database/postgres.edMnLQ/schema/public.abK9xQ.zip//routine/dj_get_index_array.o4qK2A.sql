create function dj_get_index_array(geom_array geometry[], point_geom geometry) returns integer
    language plpgsql
as
$$
DECLARE

	idx integer;

BEGIN

	idx = 0;

	FOR i IN 1..coalesce(array_length(geom_array, 1), 0)

	LOOP		

		IF ST_Intersects(ST_Buffer(ST_StartPoint(geom_array[i]), 0.0001), point_geom) THEN

			idx := i;

			EXIT;

		END IF;

	END LOOP;

	

	IF idx = 0 THEN

		FOR i IN 1..coalesce(array_length(geom_array, 1), 0)

		LOOP

			IF ST_Intersects(ST_Buffer(ST_EndPoint(geom_array[i]), 0.0001), point_geom) THEN

				idx := i * -1;

				EXIT;

			END IF;

		END LOOP;

	END IF;

	

	RETURN idx;

END

$$;

alter function dj_get_index_array(geometry[], geometry) owner to postgres;

