create function pgr_articulationpoints(text, OUT node bigint) returns SETOF bigint
    strict
    language sql
as
$$
SELECT node
    FROM _pgr_articulationPoints(_pgr_get_statement($1));
$$;

comment on function pgr_articulationpoints(text, out bigint) is 'pgr_articulationPoints
- Undirected graph
- Parameters:
  - Edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
  - https://docs.pgrouting.org/3.1/en/pgr_articulationPoints.html
';

alter function pgr_articulationpoints(text, out bigint) owner to postgres;

