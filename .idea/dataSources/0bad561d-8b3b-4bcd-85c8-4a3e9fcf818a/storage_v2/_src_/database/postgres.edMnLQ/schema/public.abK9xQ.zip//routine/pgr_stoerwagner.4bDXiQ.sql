create function pgr_stoerwagner(text, OUT seq integer, OUT edge bigint, OUT cost double precision, OUT mincut double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT *
    FROM _pgr_stoerWagner(_pgr_get_statement($1));
$$;

comment on function pgr_stoerwagner(text, out integer, out bigint, out double precision, out double precision) is 'pgr_stoerWagner
- EXPERIMENTAL
- Undirected graph
- Parameters:
  - edges SQL with columns: id, source, target, cost [,reverse_cost]
- Documentation:
  - https://docs.pgrouting.org/3.1/en/pgr_stoerWagner.html
';

alter function pgr_stoerwagner(text, out integer, out bigint, out double precision, out double precision) owner to postgres;

