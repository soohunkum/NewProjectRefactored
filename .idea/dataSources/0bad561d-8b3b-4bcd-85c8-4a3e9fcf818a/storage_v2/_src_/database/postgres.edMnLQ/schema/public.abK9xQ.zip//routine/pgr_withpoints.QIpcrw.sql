create function pgr_withpoints(text, text, anyarray, bigint, directed boolean DEFAULT true, driving_side character DEFAULT 'b'::bpchar, details boolean DEFAULT false, OUT seq integer, OUT path_seq integer, OUT start_pid bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT a.seq, a.path_seq, a.start_pid, a.node, a.edge, a.cost, a.agg_cost
    FROM _pgr_withPoints(_pgr_get_statement($1), $2, $3::bigint[], ARRAY[$4]::bigint[], $5, $6, $7, FALSE, FALSE) AS a;
$$;

comment on function pgr_withpoints(text, text, anyarray, bigint, boolean, char, boolean, out integer, out integer, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgr_withPoints (Many to One)
- PROPOSED
- Parameters:
    - Edges SQL with columns: id, source, target, cost [,reverse_cost]
    - Points SQL with columns: [pid], edge_id, fraction[,side]
    - From  ARRAY[vertices/points identifiers]
    - To vertex identifier/point identifier
- Optional Parameters
    - directed := ''true''
    - driving_side := ''b''
    - details := ''false''
- Documentation:
  - https://docs.pgrouting.org/3.1/en/pgr_withPoints.html
';

alter function pgr_withpoints(text, text, anyarray, bigint, boolean, char, boolean, out integer, out integer, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

