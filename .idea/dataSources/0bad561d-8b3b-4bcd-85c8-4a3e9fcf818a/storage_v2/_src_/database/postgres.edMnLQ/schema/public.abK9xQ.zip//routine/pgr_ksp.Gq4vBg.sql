create function pgr_ksp(text, bigint, bigint, integer, directed boolean DEFAULT true, heap_paths boolean DEFAULT false, OUT seq integer, OUT path_id integer, OUT path_seq integer, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT *
    FROM _pgr_ksp(_pgr_get_statement($1), $2, $3, $4, $5, $6);
$$;

comment on function pgr_ksp(text, bigint, bigint, integer, boolean, boolean, out integer, out integer, out integer, out bigint, out bigint, out double precision, out double precision) is 'pgr_KSP
- Parameters:
    - Edges SQL with columns: id, source, target, cost [,reverse_cost]
    - From vertex identifier
    - To vertex identifier
    - K
- Optional Parameters
    - directed := true
    - heap_paths := false
- Documentation:
    - https://docs.pgrouting.org/3.1/en/pgr_KSP.html
';

alter function pgr_ksp(text, bigint, bigint, integer, boolean, boolean, out integer, out integer, out integer, out bigint, out bigint, out double precision, out double precision) owner to postgres;

