create view viw_wtl_pipe_dir_ps(id, geom, 방향각) as
SELECT wtl_pipe_dir_ps.id,
       wtl_pipe_dir_ps.geom,
       wtl_pipe_dir_ps."방향각"
FROM wtl_pipe_dir_ps;

alter table viw_wtl_pipe_dir_ps
    owner to postgres;

