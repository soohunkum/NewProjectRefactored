create function pgr_pushrelabel(text, bigint, anyarray, OUT seq integer, OUT edge bigint, OUT start_vid bigint, OUT end_vid bigint, OUT flow bigint, OUT residual_capacity bigint) returns SETOF record
    strict
    language sql
as
$$
SELECT *
        FROM _pgr_maxflow(_pgr_get_statement($1), ARRAY[$2]::BIGINT[], $3::BIGINT[], 1);
$$;

comment on function pgr_pushrelabel(text, bigint, anyarray, out integer, out bigint, out bigint, out bigint, out bigint, out bigint) is 'pgr_pushRelabel(One to Many)
- Directed graph
- Parameters:
  - Edges SQL with columns: id, source, target, capacity [,reverse_capacity]
  - From vertex identifie
  - To ARRAY[vertices identifiers]
- Documentation:
  - https://docs.pgrouting.org/3.1/en/pgr_pushRelabel.html
';

alter function pgr_pushrelabel(text, bigint, anyarray, out integer, out bigint, out bigint, out bigint, out bigint, out bigint) owner to postgres;

