create function pgr_version() returns text
    immutable
    language sql
as
$$
SELECT '3.1.3'::varchar AS pgr_version;
$$;

comment on function pgr_version() is 'pgr_version
- Documentation
  - https://docs.pgrouting.org/3.1/en/pgr_version.html
';

alter function pgr_version() owner to postgres;

