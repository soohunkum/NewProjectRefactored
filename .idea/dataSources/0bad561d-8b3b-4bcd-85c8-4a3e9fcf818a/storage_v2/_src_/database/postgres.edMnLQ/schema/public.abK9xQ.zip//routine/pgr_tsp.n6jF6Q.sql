create function pgr_tsp(text, start_id bigint DEFAULT 0, end_id bigint DEFAULT 0, max_processing_time double precision DEFAULT 'Infinity'::double precision, tries_per_temperature integer DEFAULT 500, max_changes_per_temperature integer DEFAULT 60, max_consecutive_non_changes integer DEFAULT 100, initial_temperature double precision DEFAULT 100, final_temperature double precision DEFAULT 0.1, cooling_factor double precision DEFAULT 0.9, randomize boolean DEFAULT true, OUT seq integer, OUT node bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT *
    FROM _pgr_TSP(_pgr_get_statement($1), $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);
$$;

comment on function pgr_tsp(text, bigint, bigint, double precision, integer, integer, integer, double precision, double precision, double precision, boolean, out integer, out bigint, out double precision, out double precision) is 'pgr_TSP
- Parameters
   - matrix SQL with columns: start_vid, end_vid, agg_cost
- Optional parameters
    - start_id := 0
    - end_id := 0

    - max_processing_time := ''+infinity''::FLOAT

    - tries_per_temperature := 500
    - max_changes_per_temperature :=  60
    - max_consecutive_non_changes :=  100

    - initial_temperature FLOAT := 100
    - final_temperature := 0.1
    - cooling_factor := 0.9

    - randomize := true
- Documentation:
    - https://docs.pgrouting.org/3.1/en/pgr_TSP.html
';

alter function pgr_tsp(text, bigint, bigint, double precision, integer, integer, integer, double precision, double precision, double precision, boolean, out integer, out bigint, out double precision, out double precision) owner to postgres;

