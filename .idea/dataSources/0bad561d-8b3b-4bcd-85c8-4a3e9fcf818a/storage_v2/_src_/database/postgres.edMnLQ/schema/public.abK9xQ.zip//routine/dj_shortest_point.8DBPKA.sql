create function dj_shortest_point(point_table text, pipe_ftr_idn integer, selected_x double precision, selected_y double precision, distance double precision, layer character varying DEFAULT ''::character varying)
    returns TABLE(path_length double precision, path_geom geometry, point_layer character varying, point_ftr_idn integer, point_geom geometry)
    language plpgsql
as
$$
DECLARE

	pipe_geom geometry;

	limit_offset float;

	selected_point geometry;

	start_id integer;

	start_point geometry;

	end_id integer;

	end_point geometry;

	i integer;

	noded_vertices_id_array integer[];

	calibrated_geom_start geometry;

	calibrated_geom_end geometry;

	calibrated_geom geometry;

	calibrated_length double precision;

BEGIN

	RAISE INFO 'dj_shortest_point start parameter point_table = %, pipe_ftr_idn = %, selected_x = %, selected_y = %, distance = %, layer = %', point_table, pipe_ftr_idn, selected_x, selected_y, distance, layer;

	EXECUTE 'SELECT ST_LineMerge(pipe.geom) FROM public.wtl_pipe_lm AS pipe WHERE pipe.ftr_idn = $1' USING pipe_ftr_idn INTO pipe_geom;



	RAISE INFO 'pipe_geom = %', ST_AsText(pipe_geom);



	limit_offset := distance + ST_Length(pipe_geom);

			

	selected_point := dj_nearpoint_as_pipe(pipe_ftr_idn, selected_x, selected_y);

	RAISE INFO 'select_point = %', ST_AsText(selected_point);

			

	EXECUTE 'SELECT v.id, v.the_geom FROM public.wtl_pipe_lm_topology_noded_vertices_pgr AS v

			LEFT JOIN public.wtl_pipe_lm AS p ON ST_Intersects(ST_Buffer(v.the_geom, 0.000001), ST_StartPoint(ST_LineMerge(p.geom)))

			WHERE p.ftr_idn = $1' USING pipe_ftr_idn INTO start_id, start_point;

	

	EXECUTE 'SELECT v.id, v.the_geom FROM public.wtl_pipe_lm_topology_noded_vertices_pgr AS v

		LEFT JOIN public.wtl_pipe_lm AS p ON ST_Intersects(ST_Buffer(v.the_geom, 0.000001), ST_EndPoint(ST_LineMerge(p.geom)))

		WHERE p.ftr_idn = $1' USING pipe_ftr_idn INTO end_id, end_point;

	

	IF layer = '' THEN

		EXECUTE 'SELECT array_agg(v.id) FROM public.wtl_pipe_lm_topology_noded_vertices_pgr AS v JOIN ' || point_table ||' AS p ON ST_DWithin(v.the_geom, p.geom, 0.000001) where ST_Distance($1, p.geom) <= $2' USING selected_point, (limit_offset * 2) INTO noded_vertices_id_array;

	ELSE

		EXECUTE 'SELECT array_agg(v.id) FROM public.wtl_pipe_lm_topology_noded_vertices_pgr AS v JOIN ' || point_table ||' AS p ON ST_Dwithin(v.the_geom, p.geom, 0.000001) where ST_Distance($1, p.geom) <= $2 AND p.layer = $3' USING selected_point, (limit_offset * 2), layer INTO noded_vertices_id_array;

	END IF;

	

	IF coalesce(array_length(noded_vertices_id_array, 1), 0) = 0 THEN

		RETURN;

	END IF;

	

	RAISE INFO 'noded_vertices_id_array = %', noded_vertices_id_array;



	FOR i IN array_lower(noded_vertices_id_array, 1) .. array_upper(noded_vertices_id_array, 1)

	LOOP

		calibrated_geom := null;

		

  		RAISE INFO 'current_noded_vertices_id_array = %', noded_vertices_id_array[i];

		

		calibrated_geom_start := dj_dijkstra_and_calibrate(start_point, start_id, noded_vertices_id_array[i], selected_point, pipe_geom);

		calibrated_geom_end := dj_dijkstra_and_calibrate(end_point, end_id, noded_vertices_id_array[i], selected_point, pipe_geom);

		

		IF calibrated_geom_start IS NULL AND calibrated_geom_end IS NULL THEN

			CONTINUE;

		END IF;

		

		IF coalesce(ST_Length(calibrated_geom_start), 0) <= coalesce(ST_Length(calibrated_geom_end), 0) THEN

			calibrated_geom := coalesce(calibrated_geom_start, calibrated_geom_end);

		ELSE

			calibrated_geom := coalesce(calibrated_geom_end, calibrated_geom_start);

		END IF;

		

		IF calibrated_geom IS NULL THEN

			CONTINUE;

		END IF;

		

 		calibrated_length := ST_Length(calibrated_geom);

		

 		IF distance >= calibrated_length THEN

 			EXECUTE 'SELECT p.ftr_idn, p.geom FROM '  || point_table || ' AS p JOIN public.wtl_pipe_lm_topology_noded_vertices_pgr AS v ON ST_Intersects(ST_Buffer(p.geom, 0.000001), v.the_geom) WHERE v.id = $1' USING noded_vertices_id_array[i] INTO point_ftr_idn, point_geom;  

 			path_length := calibrated_length;

  			path_geom := calibrated_geom;

			

 			IF layer = '' THEN

 				point_layer := point_table;

 			ELSE

 				point_layer := layer;

 			END IF;

			

			RAISE INFO 'point_ftr_idn = %, path_geom = %', point_ftr_idn, ST_AsText(path_geom);



 			RETURN NEXT;

 		END IF;

		

	END LOOP;	

END

$$;

alter function dj_shortest_point(text, integer, double precision, double precision, double precision, varchar) owner to postgres;

