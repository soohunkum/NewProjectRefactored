create function dj_get_type_array(arr text[], type_name text) returns text[]
    language plpgsql
as
$$
DECLARE


	result_text text[];


	split_array text[];


BEGIN


	IF arr IS NULL THEN


-- 		RAISE NOTICE 'ARRAY IS NULL';


	ELSE


		FOR i IN array_lower(arr, 1) .. array_upper(arr, 1)


		LOOP


			split_array := string_to_array(arr[i], '|');


			


			IF	split_array[1] = type_name THEN


				result_text := array_append(result_text, arr[i]);


			END IF;


		END LOOP;


	END IF;


	


	RETURN result_text;


	


END


$$;

alter function dj_get_type_array(text[], text) owner to postgres;

