create function pgr_dijkstra(text, anyarray, bigint, directed boolean DEFAULT true, OUT seq integer, OUT path_seq integer, OUT start_vid bigint, OUT node bigint, OUT edge bigint, OUT cost double precision, OUT agg_cost double precision) returns SETOF record
    strict
    language sql
as
$$
SELECT a.seq, a.path_seq, a.start_vid, a.node, a.edge, a.cost, a.agg_cost
    FROM _pgr_dijkstra(_pgr_get_statement($1), $2::BIGINT[], ARRAY[$3]::BIGINT[], $4, false, false) AS a;
$$;

comment on function pgr_dijkstra(text, anyarray, bigint, boolean, out integer, out integer, out bigint, out bigint, out bigint, out double precision, out double precision) is 'pgr_dijkstra(Many to One)
- Parameters:
   - Edges SQL with columns: id, source, target, cost [,reverse_cost]
   - From ARRAY[vertices identifiers]
   - To vertex identifier
- Optional Parameters
   - directed := true
- Documentation:
   - https://docs.pgrouting.org/3.1/en/pgr_dijkstra.html
';

alter function pgr_dijkstra(text, anyarray, bigint, boolean, out integer, out integer, out bigint, out bigint, out bigint, out double precision, out double precision) owner to postgres;

