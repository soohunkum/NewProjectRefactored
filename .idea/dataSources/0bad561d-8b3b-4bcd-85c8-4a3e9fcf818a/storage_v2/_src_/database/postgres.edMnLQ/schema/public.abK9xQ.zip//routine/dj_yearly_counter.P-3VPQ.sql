create function dj_yearly_counter() returns integer
    language plpgsql
as
$$
DECLARE
    current_year    VARCHAR(4);
    current_rcv_num INT;
    new_rcv_num     INT;
BEGIN
    current_rcv_num = rcv_num FROM wtt_wser_ma ORDER BY id DESC LIMIT 1;
    current_year = LEFT(CAST(current_rcv_num AS VARCHAR), 4);

    IF current_year = CAST(EXTRACT(YEAR FROM CURRENT_DATE) AS VARCHAR)
    THEN
        new_rcv_num = current_rcv_num + 1;
    ELSE
        new_rcv_num = CONCAT(EXTRACT(YEAR FROM CURRENT_DATE), '000001');
    END IF;

    RETURN CAST(new_rcv_num AS INT);
END;
$$;

alter function dj_yearly_counter() owner to postgres;

