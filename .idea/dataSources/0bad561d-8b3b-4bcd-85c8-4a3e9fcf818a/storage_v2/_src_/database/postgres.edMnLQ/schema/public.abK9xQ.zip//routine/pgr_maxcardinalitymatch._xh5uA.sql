create function pgr_maxcardinalitymatch(text, directed boolean DEFAULT true, OUT seq integer, OUT edge bigint, OUT source bigint, OUT target bigint) returns SETOF record
    strict
    language sql
as
$$
SELECT *
    FROM _pgr_maxCardinalityMatch(_pgr_get_statement($1), $2)
$$;

comment on function pgr_maxcardinalitymatch(text, boolean, out integer, out bigint, out bigint, out bigint) is 'pgr_maxCardinalityMatch
- Parameters:
  - Edges SQL with columns: id, source, target, going [,coming]
- Optional Parameters:
  - directed := true
- Documentation:
  - https://docs.pgrouting.org/3.1/en/pgr_maxCardinalityMatch.html
';

alter function pgr_maxcardinalitymatch(text, boolean, out integer, out bigint, out bigint, out bigint) owner to postgres;

